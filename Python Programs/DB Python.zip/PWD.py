import pickle
f=open('pwd.dat','wb')
text='1234567890'
pickle.dump(text,f)
f.close()
