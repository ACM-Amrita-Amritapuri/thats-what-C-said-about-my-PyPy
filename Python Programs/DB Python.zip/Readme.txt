This is a database management system developed in python using simple syntax. So pls report the errors if any of them is found.

