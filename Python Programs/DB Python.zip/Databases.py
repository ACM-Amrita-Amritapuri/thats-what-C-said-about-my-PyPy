import pickle;from tabulate import tabulate;import os
def menu_1():rows=[[1,'Show Databases'],[2,'Create Database'],[3,'Use Database'],[4,'Delete Database'],[5,'Change Password'],[9,'Exit']];print(tabulate(rows,headers=['No','DATABASE MANAGEMENT'],tablefmt='grid'))
def show_databases(db):                                         
    if len(db)==0:print('No Useable Database Found')
    else:print(tabulate([[x] for x in db.keys()],headers=['DATABASES AVAILABLE'],tablefmt='grid'))    
def delete_database(db,tb):                                     
    if len(db)==0:print("NO DATABASES FOUND TO TAKE ACTION");return db
    db_name=input('The name of the database to be removed: ')  
    if db_name in db.keys():del db[db_name];del tb[db_name];print('Database deleted')
    else:print('Database not found')
    return db,tb
def create_database(db,tb):                                        
    db_name=input('Enter database name to be created: ')
    if db_name=='':return db
    elif db_name not in db.keys():db[db_name]={};tb[db_name]={};print('Database Created')
    else:print('Database already exists')
    return db,tb
def menu_2(dbna):rows=[[1,'Create Table'],[2,'Alter Table'],[3,'Insert Value'],[4,'Delete Value'],[5,'Show Table'],[6,'Show Tables'],[7,'Delete Table'],[8,'Edit Value'],[9,'Close Database']];print(tabulate(rows,headers=['No','TABLE MANAGEMENT : DATABASE - '+dbna],tablefmt='grid'))
def show_tables(db,db_name):                                    
    z=db[db_name].keys()
    if len(z)==0:print('No Tables found')
    else:print(tabulate(z,headers=['TABLE NAMES'],tablefmt='grid'))            
def delete_table(db,db_name,tb):                                
    table_name=input('Enter table name to be deleted: ')
    if table_name in db[db_name].keys():del db[db_name][table_name];del tb[db_name][table_name];print('Database Deleted')
    else:print('Table not found')
    return db,tb        
def insert_value(db,db_name,tb):                                
    table_name=input('Enter table name to enter values: ')
    if table_name in db[db_name].keys():
        z=tb[db_name][table_name];cont='y'
        while cont.lower()=='y':
            update=[]
            for i in z:print('Enter value for column name -',i,end='');update.append(input(': '))
            db[db_name][table_name].append(update);print('Value Inserted');cont=input('Do you wish to continue(Y/N): ')
    return db
def delete_value(db,db_name,tb):                                
    table_name=input('Enter table name to delete value: ')
    if len(db[db_name][table_name])==0:print('No Data found in table.');return db
    if table_name in db[db_name].keys():
        print(table_name,'-----------',tb[db_name][table_name],'-'*len(str(tb[db_name][table_name])),sep='\n');count=1
        for i in db[db_name][table_name]:print(count,i);count+=1
        try:delete_row=int(input('Enter row number to be deleted: '));ID=delete_row-1;del db[db_name][table_name][ID];print('Deletion Successful')
        except:print('An error has occured')
    else:print('Table Not found')
    return db
def info():                                                     
    data=[77, 97, 100, 101, 32, 66, 121, 32, 65, 97, 100, 105, 116, 104, 121, 97, 110, 32, 82, 97, 106, 117, 32, 73, 110, 32, 73, 78, 68, 73, 65];str_1=''
    for i in data:str_1+=chr(i)
    print(str_1)
def alter_table(db,db_name,tb):                                 
    table_name=input('Enter table name to be altered: ')
    if table_name in db[db_name].keys():
        print('1.\tAdd Column','2.\tDelete Column','3.\tClear Table','4.\tBack To Menu',sep='\n');menu_3_choice=input('Enter choice: ')
        if menu_3_choice=='4':return db,tb
        elif menu_3_choice=='3':db=clear_table(db,db_name,tb,table_name)
        elif menu_3_choice=='2':db,tb=delete_column(db,db_name,tb,table_name)
        elif menu_3_choice=='1':db,tb=add_column(db,db_name,tb,table_name)
        else:print('Invalid Input')
    else:print('Table not found!')
    return db,tb
def add_column(db,db_name,tb,tm):                               
    if tm in db[db_name].keys():
        column_name=input('Enter column name: ')
        for i in db[db_name][tm]:i.append('NONE')
        tb[db_name][tm].append(column_name);print('Column Successfully Added')
    else:print('Table Not found')
    return db,tb
def delete_column(db,db_name,tb,tm):                            
    if tm in db[db_name].keys() and len(tb[db_name][tm])>0:
        column_name=input('Enter column name: ')
        if column_name in tb[db_name][tm]:
            count=1
            for i in tb[db_name][tm]:print(count,i);count+=1
            try:
                menu_4_choice=int(input('Enter choice to delete column: '));ID=menu_4_choice-1
                del tb[db_name][tm][ID]
                for i in db[db_name][tm]:del i[ID]
                print('Column Deleted')
                if len(tb[db_name][tm])==0:del db[db_name][tm];del tb[db_name][tm];print('Table deleted due to no columns left in table')
            except:print('Enter valid choice')
        else:print('Column not found')
    else:print('Table Not found')
    return db,tb
def clear_table(db,db_name,tb,tm):                                 
    if tm in db[db_name].keys():db[db_name][tm]=[];print('Table cleared')
    else:print('Table Not found')
    return db
def create_table(db,db_name,tb):                                    
    table_name=input('Enter table name to be created: ')
    if table_name in db[db_name].keys():print('Table already exists')
    else:
        try:
            column=int(input('Enter number of columns in table: '));columns=[]
            for i in range(column):x=input('Enter column name: ');columns.append(x)
            db[db_name][table_name]=[];tb[db_name][table_name]=columns;print('Table Created')
        except:print('Enter Valid Input!')
    return db,tb
def edit_value(db,db_name,tb):                                      
    table_name=input('Enter table name to be created: ')
    if table_name in db[db_name].keys():
        table=db[db_name][table_name];column=tb[db_name][table_name];count=1
        if len(table)>0:
            print (table_name,'-'*len(table_name),column,'-'*len(str(column)),sep='\n')
            for i in table:print(count,i);count+=1
            try:
                menu_5_choice=int(input('Enter choice to edit: '));ID=menu_5_choice-1;count=1
                for i in column:print(count,i);count+=1
                menu_6_choice=input('Enter column choice: ');ID_2=menu_6_choice-1;value=input('Enter Value');table[ID][ID_2]=value;print('Value Successfully Edited')
            except:print('An error has occured')
        else:print('The table is empty')
    else:print('Table not found')
    return db
def db_load():f2=open('db.dat','rb');db=pickle.load(f2);f2.close();f2=open('tb.dat','rb');tb=pickle.load(f2);f2.close();return db,tb
def db_save(db,tb):f3=open('db.dat','wb');pickle.dump(db,f3);f3.close();f3=open('tb.dat','wb');pickle.dump(tb,f3);f3.close()
def change_password(old_pwd):
    try:
        print('\nCHANGE LOGIN PASSWORD','---------------------',sep='\n');current_password=input('ENTER CURRENT PASSWORD:- ')
        if current_password==old_pwd:
            new_password=input('ENTER NEW PASSWORD:- ');retype_passd=input('RETPYE NEW PASSWORD   :- ')
            if new_password==retype_passd:f=open('pwd.dat','wb');pickle.dump(new_password,f);f.close()
            else:print('THE NEW PASSWORD DOES NOT MATCH WITH THE RETYPED PASSWORD.')
        else:print('THE CURRENT PASSWORD IS INCORRECT.')
    except:print('AN ERROR HAS OCCURED.')
def load_password():
    try:pwd=open('pwd.dat','rb');password=pickle.load(pwd);pwd.close();return password
    except:import time;print('PASSWORD FILE NOT FOUND');time.sleep(5);os.exit()
def show_table(db,db_name,tb):                                   
    table_name=input('Enter table name to be displayed: ')
    if (table_name in db[db_name].keys())and(len(db[db_name][table_name])>0):print(tabulate(db[db_name][table_name],headers=tb[db_name][table_name],tablefmt='grid'))
    elif table_name not in db[db_name].keys():print('Table Not found')
    else:print('The table is empty')
def screen_clear():
   if os.name == 'posix':_ = os.system('clear')
   else:_ = os.system('cls')
tables={};databases={};database=False
try:databases,tables=db_load()
except:pass
password=load_password()
while True:
    print('DATABASE MANAGEMENT READY TO USE');passcode=input('PASSWORD: ')
    if password==passcode:passwd=True;break
    screen_clear()
screen_clear()
while True and passwd==True:
    menu_1();menu_1_choice=input('Enter Choice: ')
    if menu_1_choice=='1':show_databases(databases)
    elif menu_1_choice=='2':databases,tables=create_database(databases,tables)
    elif menu_1_choice=='3':
        if len(databases)==0:print('No Useable Database found');continue
        database_name=input('Enter database name to be used: ')
        if database_name in databases.keys():database=True;database_name_active=database_name;print('DATABASE OPENED')
        else:print('Database not found!')
    elif menu_1_choice=='4':databases,tables=delete_database(databases,tables)
    elif menu_1_choice=='5':change_password(password)
    elif menu_1_choice=='9':break
    else:print('Enter Valid Choice!')
    enter=input('\n\n\n\n\n\nPRESS ENTER TO CONTINUE...');screen_clear();db_save(databases,tables)
    while database==True: 
        menu_2(database_name_active);menu_2_choice=input('Enter Choice: ');db_save(databases,tables)
        if menu_2_choice in ['2','3','4','5','6','7','8']:
            if len(databases[database_name])==0:print('No Table Available');screen_clear();continue
        if menu_2_choice=='1':databases,tables=create_table(databases,database_name,tables)
        elif  menu_2_choice=='2':databases,tables=alter_table(databases,database_name,tables)
        elif  menu_2_choice=='3':databases=insert_value(databases,database_name,tables)
        elif  menu_2_choice=='4':databases=delete_value(databases,database_name,tables)
        elif  menu_2_choice=='5':show_table(databases,database_name,tables)
        elif  menu_2_choice=='6':show_tables(databases,database_name)
        elif  menu_2_choice=='7':databases,tables=delete_table(databases,database_name,tables)
        elif  menu_2_choice=='8':databases=edit_value(databases,database_name,tables)
        elif  menu_2_choice=='9':database=False
        else:print('Enter Valid Choice!')
        enter=input('\n\n\n\n\n\nPRESS ENTER TO CONTINUE...');screen_clear()
print('Thank you for using this database');info();db_save(databases,tables)